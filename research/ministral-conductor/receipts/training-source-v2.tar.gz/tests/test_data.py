from __future__ import annotations

import json
import random
import tempfile
import unittest
from pathlib import Path

from src.conductor_data import (
    FAMILIES,
    POLICIES,
    feasible,
    generate_split,
    read_jsonl,
    score_prediction,
    write_dataset,
)


class ConductorDatasetTests(unittest.TestCase):
    def test_balanced_policy_distribution_and_feasible_labels(self) -> None:
        rows = generate_split(random.Random(7), "train",  ninety := 90)
        self.assertEqual(len(rows), ninety)
        counts = {policy: 0 for policy in POLICIES}
        for row in rows:
            counts[row["label"]["policy"]] += 1
            self.assertTrue(feasible(row["label"], row["constraints"]))
            self.assertEqual(json.loads(row["target"])["policy"], row["label"]["policy"])
        self.assertEqual(counts, {"lean": 30, "balanced": 30, "strict": 30})

    def test_family_splits_are_disjoint(self) -> None:
        grouped = {
            split: {family.name for family in FAMILIES if family.split == split}
            for split in ("train", "validation", "test")
        }
        self.assertFalse(grouped["train"] & grouped["validation"])
        self.assertFalse(grouped["train"] & grouped["test"])
        self.assertFalse(grouped["validation"] & grouped["test"])

    def test_round_trip_and_oracle_score(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            manifest = write_dataset(root, seed=9, train_size=12, validation_size=6, test_size=6)
            self.assertTrue(manifest["no_user_prompts"])
            rows = read_jsonl(root / "test.jsonl")
            score = score_prediction(rows[0], rows[0]["target"])
            self.assertTrue(score["json_valid"])
            self.assertTrue(score["plan_valid"])
            self.assertTrue(score["constraint_satisfied"])
            self.assertTrue(score["exact_plan"])
            self.assertAlmostEqual(score["utility_regret"], 0.0, places=5)


if __name__ == "__main__":
    unittest.main()
