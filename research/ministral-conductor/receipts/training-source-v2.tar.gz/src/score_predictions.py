from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Any

from conductor_data import aggregate_scores, read_jsonl, score_prediction


def percentile(values: list[float], proportion: float) -> float:
    ordered = sorted(values)
    return ordered[min(len(ordered) - 1, math.ceil(proportion * len(ordered)) - 1)]


def main() -> None:
    parser = argparse.ArgumentParser(description="Score raw conductor predictions")
    parser.add_argument("--lane", required=True)
    parser.add_argument("--data", default="data/test.jsonl")
    parser.add_argument("--predictions", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    examples = {row["id"]: row for row in read_jsonl(Path(args.data))}
    predictions = read_jsonl(Path(args.predictions))
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    scores: list[dict[str, Any]] = []
    latencies: list[float] = []
    with output.open("w", encoding="utf-8") as handle:
        for record in predictions:
            example = examples[record["id"]]
            score = score_prediction(example, record.get("prediction", ""))
            scores.append(score)
            if record.get("elapsed_ms") is not None:
                latencies.append(float(record["elapsed_ms"]))
            handle.write(json.dumps({**record, "score": score}, sort_keys=True, ensure_ascii=True) + "\n")
    summary = {"lane": args.lane, **aggregate_scores(scores)}
    if latencies:
        summary.update({
            "mean_inference_ms": round(sum(latencies) / len(latencies), 3),
            "p50_inference_ms": round(percentile(latencies, 0.5), 3),
            "p95_inference_ms": round(percentile(latencies, 0.95), 3),
        })
    summary_path = output.with_suffix(".summary.json")
    summary_path.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
